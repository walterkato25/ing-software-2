<?php
  include('liblocal.php');

  $sql = "INSERT INTO etiqueta (descripcion) values ('".$_POST['descripcion']."')";

  $result = Mysql_query($sql);
  if ($result){
       echo "Se guardo la etiqueta ".$_POST["descripcion"]." correctamente.";
  }
  include('etiqueta.list.php');
  ?>