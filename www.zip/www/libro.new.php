<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/layout.css" type="text/css" media="screen">
</head>
<body id="page1">
	<div class="extra">
        <!--==============================header=================================-->
        <header>
        	<div class="barra-superior">
            	<div class="main">
                	<div class="wrapper">
                        <h1><a href="index.html">CookBook</a></h1>
                    </div>
                </div>
            </div>
            <div class="menu-row">
            	<div class="menu-border">
                	<div class="main">
                        <nav>
                            <ul class="menu">
                                <li><a href="index.html">Inicio</a></li>
                                <li><a class="active" href="libro.list.php">Libro</a></li>
                                <li><a href="etiqueta.list.php">Etiqueta</a></li>
								<li><a href="autor.list.php">Autor</a></li>
                                <li class="last"><a href="contact.html">Contáctenos</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!--==============================content================================-->
        <div class="inner">
            <div class="main">
                <section id="content">
				<table border="0">
				<form name="autorForm" action="libro.guardar.php" method="POST">
				    <tr>
                      <td><font face= "verdana" color= #000099 size=3>Nombre:</font></td><td><input type="text" name="nombre" required></td>
					  <td><font face= "verdana" color= #000099 size=3>Isbn:</font></td><td><input type="text" name="isbn" required></td>
					  <td><font face= "verdana" color= #000099 size=3>Stock:</font></td><td><input type="text" name="stock" required></td>
					</tr>
					<tr>
					  <td><font face= "verdana" color= #000099 size=3>Stock Mínimo:</font></td><td><input type="text" name="stockMinimo" required></td>
					  <td><font face= "verdana" color= #000099 size=3>Origen:</font></td><td><input type="text" name="origen" required></td>
					  <td><font face= "verdana" color= #000099 size=3>Idioma:</font></td><td><input type="text" name="idioma" required></td>
					</tr>
					<tr>
					  <td><font face= "verdana" color= #000099 size=3>Precio:</font></td><td><input type="text" name="precio"></td>
					  <td><font face= "verdana" color= #000099 size=3>Imagen:</font></td><td><input type="file" name="imagen"></td>
					</tr>
					<tr>
					  <td><font face= "verdana" color= #000099 size=3>Cant. Pág.:</font></td><td><input type="text" name="cantidadPaginas"></td>
					  <td><font face= "verdana" color= #000099 size=3>Resumén:</font></td><td><textarea name="resumen" col="5" row="3"></textarea></td>
					</tr>
					<tr>
                      <td><input type="submit" value="Guardar" /></td>
					</tr>  
                </form>
                </table>				
                </section>
                <div class="block"></div>
            </div>
        </div>
    </div>
	<!--==============================footer=================================-->
    <footer>
    	<div class="padding">
        	<div class="main">
                <div class="wrapper">
                	<div class="fleft footer-text">
                    	<span>CookBook</span> &copy; 2014
                        
                        <!-- {%FOOTER_LINK} -->
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
