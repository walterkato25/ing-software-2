<?php
  include('liblocal.php');

  $sql = "UPDATE etiqueta 
             SET descripcion = '".$_POST['descripcion']."'
           WHERE idEtiqueta = ".$_POST['etiquetaId'];			 
		   
  $result = Mysql_query($sql);
  if ($result){
       echo "Se actualizo la etiqueta correctamente.";
  }
  include('etiqueta.list.php');
  ?>