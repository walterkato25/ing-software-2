<?php
  include('liblocal.php');

  $sql = "DELETE FROM libroautor WHERE idLibro = ".$_GET['libroId']." AND idAutor = ".$_GET['autorId'];
  
  //echo $sql;
  $result = Mysql_query($sql);
  if ($result){
       echo "Se eliminó el autor para este libro correctamente.";
  }
  include('libro.editar.php');
  ?>