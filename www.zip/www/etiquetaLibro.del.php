<?php
  include('liblocal.php');

  $sql = "DELETE FROM libroetiqueta WHERE idLibro = ".$_GET['libroId']." AND idEtiqueta = ".$_GET['etiquetaId'];
  
  //echo $sql;
  $result = Mysql_query($sql);
  if ($result){
       echo "Se eliminó la etiqueta para este libro correctamente.";
  }
  include('libro.editar.php');
  ?>