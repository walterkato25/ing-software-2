<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/layout.css" type="text/css" media="screen">
	
</head>
<body id="page1">
	<div class="extra">
        <!--==============================header=================================-->
        <header>
        	<div class="barra-superior">
            	<div class="main">
                	<div class="wrapper">
                        <h1><a href="index.html">CookBook</a></h1>
                    </div>
                </div>
            </div>
            <div class="menu-row">
            	<div class="menu-border">
                	<div class="main">
                        <nav>
                            <ul class="menu">
                                <li><a href="index.html">Inicio</a></li>
                                <li><a href="libro.list.php">Libro</a></li>
                                <li><a href="etiqueta.list.php">Etiqueta</a></li>
								<li><a class="active" href="autor.list.php">Autor</a></li>
                                <li class="last"><a href="contact.html">Contáctenos</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!--==============================content================================-->
        <div class="inner">
            <div class="main">
                <section id="content">
				<form name="autorForm" action="autor.guardar.php" method="POST">
                    <font face= "verdana" color= #000099 size=3>Nombre:</font><input type="text" name="nombre" required>
					<font face= "verdana" color= #000099 size=3>Apellido:</font><input type="text" name="apellido" required>
					<font face= "verdana" color= #000099 size=3>E-mail:</font><input type="text" name="email">
                    <input type="submit" value="Guardar" />
                </form>    
                </section>
                <div class="block"></div>
            </div>
        </div>
    </div>
	<!--==============================footer=================================-->
    <footer>
    	<div class="padding">
        	<div class="main">
                <div class="wrapper">
                	<div class="fleft footer-text">
                    	<span>CookBook</span> &copy; 2014
                        
                        <!-- {%FOOTER_LINK} -->
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
