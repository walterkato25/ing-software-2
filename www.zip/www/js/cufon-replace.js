Cufon.replace('.title strong, .title em, h4', { fontFamily: 'Lobster 1.3', hover:true });
Cufon.replace('.button-1, .button-2', { fontFamily: 'NewsGoth BT', hover:true });