<?php
  include('liblocal.php');

  $sql = "UPDATE libro SET isbn = ".$_POST['isbn'].", stock = ".$_POST['stock'].", stockMinimo = ".$_POST['stockMinimo'].", 
                           img = '".$_POST['imagen']."', origen = '".$_POST['origen']."', nombre = '".$_POST['nombre']."', 
						   resumen = '".$_POST['resumen']."', idioma = '".$_POST['idioma']."', precio = ".$_POST['precio'].", 
						   cantidadPaginas = ".$_POST['cantidadPaginas']."
					 WHERE idLibro = ".$_POST['libroId'];
  
  //echo $sql;
  $result = Mysql_query($sql);
  $_GET["libroId"] = $_POST['libroId'];
  if ($result){
       echo "Se actualizo el libro ".$_POST["nombre"]." correctamente.";
  }
  include('libro.editar.php');
  ?>