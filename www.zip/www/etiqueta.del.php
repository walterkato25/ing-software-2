<?php
  include('liblocal.php');

  $sql = "DELETE FROM etiqueta WHERE idEtiqueta = ".$_GET['etiquetaId'];			 
		   
  $result = Mysql_query($sql);
  if ($result){
       echo "Se eliminó la etiqueta correctamente.";
  }
  include('etiqueta.list.php');
  ?>