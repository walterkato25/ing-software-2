<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/layout.css" type="text/css" media="screen">
</head>
<body id="page1">
	<div class="extra">
        <!--==============================header=================================-->
        <header>
        	<div class="barra-superior">
            	<div class="main">
                	<div class="wrapper">
                        <h1><a href="index.html">CookBook</a></h1>
                    </div>
                </div>
            </div>
            <div class="menu-row">
            	<div class="menu-border">
                	<div class="main">
                        <nav>
                            <ul class="menu">
                                <li><a href="index.html">Inicio</a></li>
                                <li><a class="active" href="libro.list.php">Libro</a></li>
                                <li><a href="etiqueta.list.php">Etiqueta</a></li>
								<li><a href="autor.list.php">Autor</a></li>
                                <li class="last"><a href="contact.html">Contáctenos</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!--==============================content================================-->
        <div class="inner">
            <div class="main">
                <section id="content">
				<table BORDER style="background-color:#00FFCC;" cellspacing=7 cellpadding=2 style="font-size: 8pt" >
				  <tr>
                    <th><font  face="verdana" color= "0000FF" size=4 ><u>ID</u></font></th>
					<th><font  face="verdana" color= "0000FF" size=4 ><u>Nombre</u></font></th>
                    <th><font  face="verdana" color= "0000FF" size=4 ><u>Isbn</u></font></th>
					<th><font  face="verdana" color= "0000FF" size=4 ><u>Stock</u></font></th>
					<th><font  face="verdana" color= "0000FF" size=4 ><u>Stock Mínimo</u></font></th>
					<th><font  face="verdana" color= "0000FF" size=4 ><u>Origen</u></font></th>
					<th><font  face="verdana" color= "0000FF" size=4 ><u>Precio</u></font></th>
                    <th colspan="2"><font  face="verdana" color= "0000FF" size=4 u>Acciones</u></font></th>
                  </tr>
				<?php
                include('liblocal.php');
  
			     $result = Mysql_query("SELECT *
				    					  FROM libro
								      ORDER BY nombre");
			     $numero = 0; 
			     while($row = mysql_fetch_array($result))
			    {
				    echo "<tr><td width=\"25%\"><font face=\"verdana\" color= #CC66CC size=2><strong>".$row["idLibro"]."</strong></font></td>";
				    echo "<td width=\"25%\"><font face=\"verdana\" color= #000099 size=2>".$row["nombre"]."</font></td>";
					echo "<td width=\"25%\"><font face=\"verdana\" color= #000099 size=2>".$row["isbn"]."</font></td>";
					echo "<td width=\"25%\"><font face=\"verdana\" color= #000099 size=2>".$row["stock"]."</font></td>";
					echo "<td width=\"25%\"><font face=\"verdana\" color= #000099 size=2>".$row["stockMinimo"]."</font></td>";
					echo "<td width=\"25%\"><font face=\"verdana\" color= #000099 size=2>".$row["origen"]."</font></td>";
					echo "<td width=\"25%\"><font face=\"verdana\" color= #000099 size=2>".$row["precio"]."</font></td>";
				    echo "<td width=\"25%\"><font face=\"verdana\"><a href='libro.del.php?libroId=".$row['idLibro']."'>Eliminar</a></font></td>";
				    echo "<td width=\"25%\"><font face=\"verdana\"><a href='libro.editar.php?libroId=".$row['idLibro']."'>Editar</a></font></td></tr>";
				    $numero++;
			    }
			    echo "<tr><td colspan=\"15\"><font face=\"verdana\"><b>Número: ".$numero."</b></font></td></tr></table>";    
				?>
				<input type="button" value="Nuevo" onclick="window.location.href = 'libro.new.php';" />
                </section>
                <div class="block"></div>
            </div>
        </div>
    </div>
	<!--==============================footer=================================-->
    <footer>
    	<div class="padding">
        	<div class="main">
                <div class="wrapper">
                	<div class="fleft footer-text">
                    	<span>CookBook</span> &copy; 2014
                        
                        <!-- {%FOOTER_LINK} -->
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
