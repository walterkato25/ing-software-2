<?php
  include('liblocal.php');

  $sql = "INSERT INTO libroetiqueta (idLibro, idEtiqueta) 
                          VALUES (".$_POST['libroId'].", ".$_POST['etiquetaId'].")";
  
  //echo $sql;
  $result = Mysql_query($sql);
  $_GET["libroId"] = $_POST['libroId'];
  if ($result){
       echo "Se guardo la etiqueta para este libro correctamente.";
  }
  include('libro.editar.php');
  ?>