<?php
  include('liblocal.php');

  $sql = "DELETE FROM autor WHERE idAutor = ".$_GET['autorId'];			 
		   
  $result = Mysql_query($sql);
  if ($result){
       echo "Se eliminó el autor correctamente.";
  }
  include('autor.list.php');
  ?>