<?php
  include('liblocal.php');

  $sql = "SELECT * 
            FROM autor 
		   WHERE nombre = '".$_POST['nombre']."'
		     AND apellido = '".$_POST['apellido']."'";
   
   $result = Mysql_query($sql);
   if (mysql_num_rows($result) > 0){
       echo "<font face='verdana' size='2', color='red'>El autor ".$_POST["nombre"].", ".$_POST["apellido"]." ya existe.</font>";
	} else {
		$sql = "INSERT INTO autor (nombre, apellido, mail) values ('".$_POST['nombre']."', '".$_POST['apellido']."', '".$_POST['email']."')";

		$result = Mysql_query($sql);
		if ($result){
			echo "Se guardo el autor ".$_POST["nombre"].", ".$_POST["apellido"]." correctamente.";
		}
	}
  include('autor.list.php');
  ?>