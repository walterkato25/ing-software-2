<?php
  include('liblocal.php');

  $sql = "INSERT INTO libro (isbn, stock, stockMinimo, img, origen, nombre, resumen, idioma, precio, cantidadPaginas) 
                     VALUES (".$_POST['isbn'].", ".$_POST['stock'].", ".$_POST['stockMinimo'].", '".$_POST['imagen']."',
					         '".$_POST['origen']."', '".$_POST['nombre']."', '".$_POST['resumen']."', '".$_POST['idioma']."',
							 ".$_POST['precio'].", ".$_POST['cantidadPaginas'].")";
  
  //echo $sql;
  $result = Mysql_query($sql);
  $_GET["libroId"] = mysql_insert_id();
  if ($result){
       echo "Se guardo el libro ".$_POST["nombre"]." correctamente.";
  }
  include('libro.editar.php');
  ?>