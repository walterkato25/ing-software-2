<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/layout.css" type="text/css" media="screen">
	<script type="text/javascript">	
	    function recargarImagen(){
		    document.getElementById("imagenAmostrar").src = './libroimg/'+document.getElementById("imagen").value;
		}
	</script>
</head>
<body id="page1">
	<div class="extra">
        <!--==============================header=================================-->
        <header>
        	<div class="barra-superior">
            	<div class="main">
                	<div class="wrapper">
                        <h1><a href="index.html">CookBook</a></h1>
                    </div>
                </div>
            </div>
            <div class="menu-row">
            	<div class="menu-border">
                	<div class="main">
                        <nav>
                            <ul class="menu">
                                <li><a href="index.html">Inicio</a></li>
                                <li><a class="active" href="libro.list.php">Libro</a></li>
                                <li><a href="etiqueta.list.php">Etiqueta</a></li>
								<li><a href="autor.list.php">Autor</a></li>
                                <li class="last"><a href="contact.html">Contáctenos</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!--==============================content================================-->
        <div class="inner">
            <div class="main">
                <section id="content">
				<?PHP
				 include('liblocal.php');
				 
				 $result = Mysql_query("SELECT *
				    					  FROM libro
								         WHERE idLibro = ".$_GET['libroId']);
			     $row = mysql_fetch_array($result);
				?>
				<table border="0">
				<form name="autorForm" action="libro.actualizar.php" method="POST">
				     <input type="hidden" name="libroId" value="<?php echo $row['idLibro'] ?>">
				    <tr>
                      <td><font face= "verdana" color= #000099 size=3>Nombre:</font></td><td><input type="text" name="nombre" value="<?php echo $row['nombre'] ?>" required></td>
					  <td><font face= "verdana" color= #000099 size=3>Isbn:</font></td><td><input type="text" name="isbn" value="<?php echo $row['isbn'] ?>" required></td>
					  <td><font face= "verdana" color= #000099 size=3>Stock:</font></td><td><input type="text" name="stock" value="<?php echo $row['stock'] ?>" required></td>
					</tr>
					<tr>
					  <td><font face= "verdana" color= #000099 size=3>Stock Mínimo:</font></td><td><input type="text" name="stockMinimo" value="<?php echo $row['stockMinimo'] ?>" required></td>
					  <td><font face= "verdana" color= #000099 size=3>Origen:</font></td><td><input type="text" name="origen" value="<?php echo $row['origen'] ?>" required></td>
					  <td><font face= "verdana" color= #000099 size=3>Idioma:</font></td><td><input type="text" name="idioma" value="<?php echo $row['idioma'] ?>" required></td>
					</tr>
					<tr>
					  <td><font face= "verdana" color= #000099 size=3>Precio:</font></td><td><input type="text" name="precio" value="<?php echo $row['precio'] ?>"></td>
					  <td><font face= "verdana" color= #000099 size=3>Cant. Pág.:</font></td><td><input type="text" name="cantidadPaginas" value="<?php echo $row['cantidadPaginas'] ?>"></td>
					</tr>
					<tr>
					  <td><font face= "verdana" color= #000099 size=3>Resumén:</font></td><td><textarea name="resumen" col="5" row="3"><?php echo $row['resumen'] ?></textarea></td>
					  <td><font face= "verdana" color= #000099 size=3>Imagen:</font></td><td><input type="file" id="imagen" name="imagen" value="<?php echo $row['img'] ?>" onchange="recargarImagen();"></td>
					  <td><img id="imagenAmostrar" src="./libroimg/<?php echo $row['img']; ?>" height="80" width="80" /></td>
					</tr>
					<tr>
                      <td><input type="submit" value="Actualizar" /></td>
					</tr>  
                </form>
                </table>
				<?PHP				 
				$result = Mysql_query("SELECT idAutor, nombre, apellido
				    					 FROM autor
										WHERE idAutor NOT IN (SELECT idAutor FROM libroautor WHERE idLibro = ".$_GET['libroId'].")
								     ORDER BY nombre");
				?>
				<form name="libroAutorForm" action="autorLibro.guardar.php" method="POST">
				    <input type="hidden" name="libroId" value="<?php echo $row['idLibro'] ?>">
                    <font face= "verdana" color= #000099 size=3>Autor:</font>
					<select name="autorId" required>
					    <?PHP
						while($rowAutor = mysql_fetch_array($result))
			            {
						    echo "<option value='".$rowAutor['idAutor']."'>".$rowAutor['apellido'].", ".$rowAutor['nombre']."</option>";
						}
						?>
                    </select>
                    <input type="submit" value="Agregar Autor" />
                </form>
				
				<?PHP
				$result = Mysql_query("SELECT autor.*
				    					  FROM libroautor, autor
									     WHERE idLibro = ".$_GET['libroId']."
										   AND libroautor.idAutor = autor.idAutor
								      ORDER BY autor.apellido, autor.nombre");
				  
				 if (mysql_num_rows($result) > 0){
				     ?>
				     <table border="1" cellspacing=7 cellpadding=2 style="font-size: 8pt">
					  <tr>
						<th><font face="verdana" color= #99CCCC size=4><u>ID</u></font></th>
						<th><font face="verdana" color= #99CCCC size=4><u>Nombre</u></font></th>
						<th><font face="verdana" color= #99CCCC size=4><u>Apellido</u></font></th>
						<th><font face="verdana" color= #99CCCC size=4><u>E-mail</u></font></th>
						<th><font face="verdana" color= #99CCCC size= 4><u>Acciones</u></font></th>
					  </tr>
					<?PHP
					 $numero = 0; 
					 while($rowLibroAutor = mysql_fetch_array($result))
					{
						echo "<tr><td width=\"25%\"><font face=\"verdana\" color= #CC66CC size=2><strong>".$rowLibroAutor["idAutor"]."</strong></font></td>";
						echo "<td width=\"25%\"><font face=\"verdana\" color= #000099 size=2>".$rowLibroAutor["nombre"]."</font></td>";
						echo "<td width=\"25%\"><font face=\"verdana\" color= #000099 size=2>".$rowLibroAutor["apellido"]."</font></td>";
						echo "<td width=\"25%\"><font face=\"verdana\" color= #000099 size=2>".$rowLibroAutor["mail"]."</font></td>";
						echo "<td width=\"25%\"><font face=\"verdana\"><a href='autorLibro.del.php?autorId=".$rowLibroAutor['idAutor']."&libroId=".$_GET['libroId']."'>Eliminar</a></font></td>";
						$numero++;
					}
					echo "<tr><td colspan=\"15\"><font face=\"verdana\"><b>Número: ".$numero."</b></font></td></tr></table>";   
                }					
				    ?>
				
				<?PHP				 
				$result = Mysql_query("SELECT idEtiqueta, descripcion
				    					 FROM etiqueta
										WHERE idEtiqueta NOT IN (SELECT idEtiqueta FROM libroetiqueta WHERE idLibro = ".$_GET['libroId'].")
								     ORDER BY descripcion");
				?>
				<form name="libroEtiquetaForm" action="etiquetaLibro.guardar.php" method="POST">
				    <input type="hidden" name="libroId" value="<?php echo $row['idLibro'] ?>">
                    <font face= "verdana" color= #000099 size=3>Etiqueta:</font>
					<select name="etiquetaId" required>
					    <?PHP
						while($rowEtiqueta = mysql_fetch_array($result))
			            {
						    echo "<option value='".$rowEtiqueta['idEtiqueta']."'>".$rowEtiqueta['descripcion']."</option>";
						}
						?>
                    </select>
                    <input type="submit" value="Agregar Etiqueta" />
                </form>
				
				<?PHP
				$result = Mysql_query("SELECT etiqueta.*
				    					  FROM libroetiqueta, etiqueta
									     WHERE idLibro = ".$_GET['libroId']."
										   AND libroetiqueta.idEtiqueta = etiqueta.idEtiqueta
								      ORDER BY etiqueta.descripcion");
				  
				 if (mysql_num_rows($result) > 0){
				     ?>
				     <table border="1" cellspacing=7 cellpadding=2 style="font-size: 8pt">
					  <tr>
						<th><font face="verdana" color= #99CCCC size=4><u>ID</u></font></th>
						<th><font face="verdana" color= #99CCCC size=4><u>Descripción</u></font></th>
						<th><font face="verdana" color= #99CCCC size= 4><u>Acciones</u></font></th>
					  </tr>
					<?PHP
					 $numero = 0; 
					 while($rowLibroEtiqueta = mysql_fetch_array($result))
					{
						echo "<tr><td width=\"25%\"><font face=\"verdana\" color= #CC66CC size=2><strong>".$rowLibroEtiqueta["idEtiqueta"]."</strong></font></td>";
						echo "<td width=\"25%\"><font face=\"verdana\" color= #000099 size=2>".$rowLibroEtiqueta["descripcion"]."</font></td>";
						echo "<td width=\"25%\"><font face=\"verdana\"><a href='etiquetaLibro.del.php?etiquetaId=".$rowLibroEtiqueta['idEtiqueta']."&libroId=".$_GET['libroId']."'>Eliminar</a></font></td>";
						$numero++;
					}
					echo "<tr><td colspan=\"15\"><font face=\"verdana\"><b>Número: ".$numero."</b></font></td></tr></table>";   
                }					
				    ?>
                </section>
                <div class="block"></div>
            </div>
        </div>
    </div>
	<!--==============================footer=================================-->
    <footer>
    	<div class="padding">
        	<div class="main">
                <div class="wrapper">
                	<div class="fleft footer-text">
                    	<span>CookBook</span> &copy; 2014
                        
                        <!-- {%FOOTER_LINK} -->
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
