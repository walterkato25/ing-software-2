<?php
  include('liblocal.php');

  $sql = "INSERT INTO libroautor (idLibro, idAutor) 
                          VALUES (".$_POST['libroId'].", ".$_POST['autorId'].")";
  
  //echo $sql;
  $result = Mysql_query($sql);
  $_GET["libroId"] = $_POST['libroId'];
  if ($result){
       echo "Se guardo el autor para este libro correctamente.";
  }
  include('libro.editar.php');
  ?>